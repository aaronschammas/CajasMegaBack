"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { useToast } from "@/hooks/use-toast"
import { Trash2 } from "lucide-react"

// Tipos
interface Usuario {
  id: number
  nombre: string
}

interface Concepto {
  id: number
  nombre: string
}

interface Movimiento {
  id: string
  tipo: "Ingreso" | "Egreso"
  turno: "M" | "T"
  conceptoId: number
  conceptoNombre: string
  monto: number
  realizadoPorId: number
  realizadoPorNombre: string
  detalle: string
  fecha: string
}

export default function MovimientoForm({ tipo }: { tipo: "Ingreso" | "Egreso" }) {
  // Estados para el formulario
  const [turno, setTurno] = useState<"M" | "T">("M")
  const [conceptoId, setConceptoId] = useState("")
  const [monto, setMonto] = useState("")
  const [realizadoPorId, setRealizadoPorId] = useState("")
  const [detalle, setDetalle] = useState("")

  // Estados para datos de selects
  const [usuarios, setUsuarios] = useState<Usuario[]>([])
  const [conceptos, setConceptos] = useState<Concepto[]>([])

  // Estado para la pila de movimientos
  const [movimientosPendientes, setMovimientosPendientes] = useState<Movimiento[]>([])
  const [movimientosAgregados, setMovimientosAgregados] = useState<Movimiento[]>([])

  const router = useRouter()
  const { toast } = useToast()

  // Obtener fecha actual formateada
  const fechaActual = new Date().toLocaleDateString("es-ES", {
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
  })

  // Simular carga de datos iniciales
  useEffect(() => {
    // En una implementación real, estos datos vendrían de la API
    setUsuarios([
      { id: 1, nombre: "Juan Pérez" },
      { id: 2, nombre: "María López" },
      { id: 3, nombre: "Carlos Rodríguez" },
    ])

    setConceptos([
      { id: 1, nombre: "Venta al contado" },
      { id: 2, nombre: "Pago de cliente" },
      { id: 3, nombre: "Pago de alquiler" },
      { id: 4, nombre: "Compra de insumos" },
      { id: 5, nombre: "Otro" },
    ])

    // Simular movimientos ya agregados
    setMovimientosAgregados([
      {
        id: "20250522-001-1",
        tipo: "Ingreso",
        turno: "M",
        conceptoId: 1,
        conceptoNombre: "Venta al contado",
        monto: 1500.0,
        realizadoPorId: 1,
        realizadoPorNombre: "Juan Pérez",
        detalle: "Venta de productos varios",
        fecha: "22/05/2025",
      },
      {
        id: "20250522-002-2",
        tipo: "Egreso",
        turno: "T",
        conceptoId: 4,
        conceptoNombre: "Compra de insumos",
        monto: 500.0,
        realizadoPorId: 2,
        realizadoPorNombre: "María López",
        detalle: "Compra de papelería",
        fecha: "22/05/2025",
      },
    ])

    // Cargar movimientos pendientes del localStorage si existen
    const pendientesGuardados = localStorage.getItem("movimientosPendientes")
    if (pendientesGuardados) {
      try {
        setMovimientosPendientes(JSON.parse(pendientesGuardados))
      } catch (e) {
        console.error("Error al cargar movimientos pendientes", e)
      }
    }
  }, [])

  // Guardar movimientos pendientes en localStorage cuando cambien
  useEffect(() => {
    localStorage.setItem("movimientosPendientes", JSON.stringify(movimientosPendientes))
  }, [movimientosPendientes])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    // Validaciones básicas
    if (!conceptoId || !monto || !realizadoPorId) {
      toast({
        title: "Error en el formulario",
        description: "Todos los campos son obligatorios",
        variant: "destructive",
      })
      return
    }

    // Crear ID de referencia único (en producción esto vendría del backend)
    const fecha = new Date()
    const año = fecha.getFullYear()
    const mes = String(fecha.getMonth() + 1).padStart(2, "0")
    const dia = String(fecha.getDate()).padStart(2, "0")
    const contador = movimientosPendientes.length + movimientosAgregados.length + 1
    const usuarioId = Number.parseInt(realizadoPorId)
    const referenceId = `${año}${mes}${dia}-${String(contador).padStart(3, "0")}-${usuarioId}`

    // Encontrar nombres para los IDs seleccionados
    const conceptoSeleccionado = conceptos.find((c) => c.id === Number.parseInt(conceptoId))
    const usuarioSeleccionado = usuarios.find((u) => u.id === Number.parseInt(realizadoPorId))

    // Crear nuevo movimiento
    const nuevoMovimiento: Movimiento = {
      id: referenceId,
      tipo,
      turno,
      conceptoId: Number.parseInt(conceptoId),
      conceptoNombre: conceptoSeleccionado?.nombre || "",
      monto: Number.parseFloat(monto),
      realizadoPorId: Number.parseInt(realizadoPorId),
      realizadoPorNombre: usuarioSeleccionado?.nombre || "",
      detalle,
      fecha: fechaActual,
    }

    // Agregar a la pila de pendientes
    setMovimientosPendientes([...movimientosPendientes, nuevoMovimiento])

    // Limpiar formulario
    setTurno("M")
    setConceptoId("")
    setMonto("")
    setRealizadoPorId("")
    setDetalle("")

    toast({
      title: "Movimiento agregado a la pila",
      description: "El movimiento se ha agregado a la pila de pendientes",
    })
  }

  const eliminarMovimientoPendiente = (id: string) => {
    setMovimientosPendientes(movimientosPendientes.filter((m) => m.id !== id))

    toast({
      title: "Movimiento eliminado",
      description: "El movimiento se ha eliminado de la pila de pendientes",
    })
  }

  const enviarABaseDeDatos = async () => {
    if (movimientosPendientes.length === 0) {
      toast({
        title: "No hay movimientos pendientes",
        description: "Agrega movimientos a la pila antes de enviar",
        variant: "destructive",
      })
      return
    }

    try {
      // En una implementación real, esto sería una llamada a la API
      // const response = await fetch("/api/movimientos/batch", {
      //   method: "POST",
      //   headers: {
      //     "Content-Type": "application/json",
      //     "Authorization": `Bearer ${localStorage.getItem("token")}`
      //   },
      //   body: JSON.stringify({ movimientos: movimientosPendientes }),
      // });

      // if (!response.ok) {
      //   throw new Error("Error al guardar los movimientos");
      // }

      // Simulamos una respuesta exitosa
      // Movemos los pendientes a agregados
      setMovimientosAgregados([...movimientosAgregados, ...movimientosPendientes])
      setMovimientosPendientes([])

      toast({
        title: "Movimientos guardados",
        description: `Se han guardado ${movimientosPendientes.length} movimientos en la base de datos`,
      })
    } catch (error) {
      toast({
        title: "Error al guardar",
        description: "No se pudieron guardar los movimientos en la base de datos",
        variant: "destructive",
      })
    }
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      {/* Formulario */}
      <div className="lg:col-span-1">
        <Card>
          <CardHeader>
            <CardTitle>Nuevo {tipo}</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="turno">Turno</Label>
                <Select value={turno} onValueChange={(value: "M" | "T") => setTurno(value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Selecciona el turno" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="M">Mañana (M)</SelectItem>
                    <SelectItem value="T">Tarde (T)</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="concepto">Movimiento de</Label>
                <Select value={conceptoId} onValueChange={setConceptoId}>
                  <SelectTrigger>
                    <SelectValue placeholder="Selecciona el concepto" />
                  </SelectTrigger>
                  <SelectContent>
                    {conceptos.map((concepto) => (
                      <SelectItem key={concepto.id} value={concepto.id.toString()}>
                        {concepto.nombre}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="monto">Monto</Label>
                <Input
                  id="monto"
                  type="number"
                  step="0.01"
                  min="0"
                  placeholder="0.00"
                  value={monto}
                  onChange={(e) => setMonto(e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="realizadoPor">Movimiento realizado por</Label>
                <Select value={realizadoPorId} onValueChange={setRealizadoPorId}>
                  <SelectTrigger>
                    <SelectValue placeholder="Selecciona el usuario" />
                  </SelectTrigger>
                  <SelectContent>
                    {usuarios.map((usuario) => (
                      <SelectItem key={usuario.id} value={usuario.id.toString()}>
                        {usuario.nombre}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="detalle">Detalle</Label>
                <Textarea
                  id="detalle"
                  placeholder="Descripción del movimiento"
                  value={detalle}
                  onChange={(e) => setDetalle(e.target.value)}
                  rows={3}
                />
              </div>

              <div className="flex justify-between items-center pt-2">
                <div className="text-sm text-gray-500">Fecha actual: {fechaActual}</div>
                <Button type="submit">Agregar a la pila</Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>

      {/* Pila de movimientos */}
      <div className="lg:col-span-2">
        <div className="space-y-6">
          {/* Movimientos pendientes */}
          <Card>
            <CardHeader className="pb-3">
              <div className="flex justify-between items-center">
                <CardTitle>Por enviar a la DB</CardTitle>
                <Button onClick={enviarABaseDeDatos} disabled={movimientosPendientes.length === 0}>
                  Enviar a la DB
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              {movimientosPendientes.length === 0 ? (
                <p className="text-center text-gray-500 py-4">No hay movimientos pendientes</p>
              ) : (
                <div className="space-y-3">
                  {movimientosPendientes.map((movimiento) => (
                    <div key={movimiento.id} className="flex justify-between items-start p-3 border rounded-md">
                      <div>
                        <div className="font-medium">{movimiento.id}</div>
                        <div className="text-sm">
                          <span className={movimiento.tipo === "Ingreso" ? "text-green-600" : "text-red-600"}>
                            {movimiento.tipo}
                          </span>
                          {" - "}
                          {movimiento.conceptoNombre}
                        </div>
                        <div className="text-sm">
                          ${movimiento.monto.toFixed(2)} - Turno: {movimiento.turno}
                        </div>
                        <div className="text-sm text-gray-500">Por: {movimiento.realizadoPorNombre}</div>
                        {movimiento.detalle && <div className="text-sm mt-1">{movimiento.detalle}</div>}
                      </div>
                      <Button variant="ghost" size="icon" onClick={() => eliminarMovimientoPendiente(movimiento.id)}>
                        <Trash2 className="h-4 w-4 text-red-500" />
                      </Button>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Movimientos ya agregados */}
          <Card>
            <CardHeader>
              <CardTitle>Movimientos ya agregados / en la DB</CardTitle>
            </CardHeader>
            <CardContent>
              {movimientosAgregados.length === 0 ? (
                <p className="text-center text-gray-500 py-4">No hay movimientos guardados</p>
              ) : (
                <div className="space-y-3">
                  {movimientosAgregados.map((movimiento) => (
                    <div key={movimiento.id} className="p-3 border rounded-md">
                      <div className="font-medium">{movimiento.id}</div>
                      <div className="text-sm">
                        <span className={movimiento.tipo === "Ingreso" ? "text-green-600" : "text-red-600"}>
                          {movimiento.tipo}
                        </span>
                        {" - "}
                        {movimiento.conceptoNombre}
                      </div>
                      <div className="text-sm">
                        ${movimiento.monto.toFixed(2)} - Turno: {movimiento.turno}
                      </div>
                      <div className="text-sm text-gray-500">
                        Por: {movimiento.realizadoPorNombre} - {movimiento.fecha}
                      </div>
                      {movimiento.detalle && <div className="text-sm mt-1">{movimiento.detalle}</div>}
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
