"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { User, LogOut, Menu, X } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [userName, setUserName] = useState("")
  const router = useRouter()
  const { toast } = useToast()

  useEffect(() => {
    // Obtener información del usuario del localStorage
    const userStr = localStorage.getItem("user")
    if (userStr) {
      try {
        const user = JSON.parse(userStr)
        setUserName(user.fullName || user.email)
      } catch (e) {
        console.error("Error parsing user data", e)
      }
    } else {
      // Si no hay usuario, redirigir al login
      router.push("/")
    }
  }, [router])

  const handleLogout = () => {
    // Eliminar token y datos de usuario
    localStorage.removeItem("token")
    localStorage.removeItem("user")

    toast({
      title: "Sesión cerrada",
      description: "Has cerrado sesión correctamente",
    })

    router.push("/")
  }

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen)
  }

  return (
    <header className="fixed w-full bg-white shadow-md z-10">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center">
            <Link href="/movimientos" className="text-lg font-bold">
              Sistema de Control de Caja
            </Link>
          </div>

          {/* Menú para móviles */}
          <div className="md:hidden">
            <Button variant="ghost" size="icon" onClick={toggleMenu}>
              {isMenuOpen ? <X /> : <Menu />}
            </Button>
          </div>

          {/* Menú para desktop */}
          <nav className="hidden md:flex items-center space-x-4">
            <Link href="/movimientos" className="px-3 py-2 rounded-md hover:bg-gray-100">
              Inicio
            </Link>
            <Link href="/movimientos/ingresos" className="px-3 py-2 rounded-md hover:bg-gray-100">
              Ingresos
            </Link>
            <Link href="/movimientos/egresos" className="px-3 py-2 rounded-md hover:bg-gray-100">
              Egresos
            </Link>
            <Link href="/movimientos/historial" className="px-3 py-2 rounded-md hover:bg-gray-100">
              Historial
            </Link>

            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" size="sm" className="ml-4">
                  <User className="h-4 w-4 mr-2" />
                  {userName || "Usuario"}
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuLabel>Mi cuenta</DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem asChild>
                  <Link href="/perfil">Perfil</Link>
                </DropdownMenuItem>
                <DropdownMenuItem onClick={handleLogout} className="text-red-500">
                  <LogOut className="h-4 w-4 mr-2" />
                  Cerrar sesión
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </nav>
        </div>

        {/* Menú móvil expandible */}
        {isMenuOpen && (
          <div className="md:hidden bg-white pb-4">
            <div className="flex flex-col space-y-2">
              <Link
                href="/movimientos"
                className="px-3 py-2 rounded-md hover:bg-gray-100"
                onClick={() => setIsMenuOpen(false)}
              >
                Inicio
              </Link>
              <Link
                href="/movimientos/ingresos"
                className="px-3 py-2 rounded-md hover:bg-gray-100"
                onClick={() => setIsMenuOpen(false)}
              >
                Ingresos
              </Link>
              <Link
                href="/movimientos/egresos"
                className="px-3 py-2 rounded-md hover:bg-gray-100"
                onClick={() => setIsMenuOpen(false)}
              >
                Egresos
              </Link>
              <Link
                href="/movimientos/historial"
                className="px-3 py-2 rounded-md hover:bg-gray-100"
                onClick={() => setIsMenuOpen(false)}
              >
                Historial
              </Link>
              <Link
                href="/perfil"
                className="px-3 py-2 rounded-md hover:bg-gray-100"
                onClick={() => setIsMenuOpen(false)}
              >
                Perfil
              </Link>
              <Button
                variant="ghost"
                className="justify-start text-red-500"
                onClick={() => {
                  setIsMenuOpen(false)
                  handleLogout()
                }}
              >
                <LogOut className="h-4 w-4 mr-2" />
                Cerrar sesión
              </Button>
            </div>
          </div>
        )}
      </div>
    </header>
  )
}
