"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { ArrowUpCircle, ArrowDownCircle, Search, FileDown } from "lucide-react"

// Tipos
interface Movimiento {
  id: string
  tipo: "Ingreso" | "Egreso"
  turno: "M" | "T"
  conceptoId: number
  conceptoNombre: string
  monto: number
  realizadoPorId: number
  realizadoPorNombre: string
  detalle: string
  fecha: string
}

interface Usuario {
  id: number
  nombre: string
}

interface Concepto {
  id: number
  nombre: string
}

export default function HistorialMovimientos() {
  // Estados para filtros
  const [fechaDesde, setFechaDesde] = useState("")
  const [fechaHasta, setFechaHasta] = useState("")
  const [usuarioId, setUsuarioId] = useState("")
  const [conceptoId, setConceptoId] = useState("")
  const [turno, setTurno] = useState("")
  const [tipo, setTipo] = useState("")
  const [referenceId, setReferenceId] = useState("")

  // Estados para datos
  const [movimientos, setMovimientos] = useState<Movimiento[]>([])
  const [movimientosFiltrados, setMovimientosFiltrados] = useState<Movimiento[]>([])
  const [usuarios, setUsuarios] = useState<Usuario[]>([])
  const [conceptos, setConceptos] = useState<Concepto[]>([])

  // Simular carga de datos iniciales
  useEffect(() => {
    // En una implementación real, estos datos vendrían de la API
    setUsuarios([
      { id: 1, nombre: "Juan Pérez" },
      { id: 2, nombre: "María López" },
      { id: 3, nombre: "Carlos Rodríguez" },
    ])

    setConceptos([
      { id: 1, nombre: "Venta al contado" },
      { id: 2, nombre: "Pago de cliente" },
      { id: 3, nombre: "Pago de alquiler" },
      { id: 4, nombre: "Compra de insumos" },
      { id: 5, nombre: "Otro" },
    ])

    // Simular movimientos
    const movimientosSimulados: Movimiento[] = [
      {
        id: "20250522-001-1",
        tipo: "Ingreso",
        turno: "M",
        conceptoId: 1,
        conceptoNombre: "Venta al contado",
        monto: 1500.0,
        realizadoPorId: 1,
        realizadoPorNombre: "Juan Pérez",
        detalle: "Venta de productos varios",
        fecha: "22/05/2025",
      },
      {
        id: "20250522-002-2",
        tipo: "Egreso",
        turno: "T",
        conceptoId: 4,
        conceptoNombre: "Compra de insumos",
        monto: 500.0,
        realizadoPorId: 2,
        realizadoPorNombre: "María López",
        detalle: "Compra de papelería",
        fecha: "22/05/2025",
      },
      {
        id: "20250521-001-3",
        tipo: "Ingreso",
        turno: "M",
        conceptoId: 2,
        conceptoNombre: "Pago de cliente",
        monto: 2500.0,
        realizadoPorId: 3,
        realizadoPorNombre: "Carlos Rodríguez",
        detalle: "Pago factura #12345",
        fecha: "21/05/2025",
      },
      {
        id: "20250521-002-1",
        tipo: "Egreso",
        turno: "M",
        conceptoId: 3,
        conceptoNombre: "Pago de alquiler",
        monto: 1200.0,
        realizadoPorId: 1,
        realizadoPorNombre: "Juan Pérez",
        detalle: "Alquiler mes de mayo",
        fecha: "21/05/2025",
      },
      {
        id: "20250520-001-2",
        tipo: "Ingreso",
        turno: "T",
        conceptoId: 1,
        conceptoNombre: "Venta al contado",
        monto: 800.0,
        realizadoPorId: 2,
        realizadoPorNombre: "María López",
        detalle: "Venta de servicios",
        fecha: "20/05/2025",
      },
    ]

    setMovimientos(movimientosSimulados)
    setMovimientosFiltrados(movimientosSimulados)
  }, [])

  // Aplicar filtros
  const aplicarFiltros = () => {
    let resultados = [...movimientos]

    // Filtrar por ID de referencia
    if (referenceId) {
      resultados = resultados.filter((m) => m.id.toLowerCase().includes(referenceId.toLowerCase()))
    }

    // Filtrar por tipo
    if (tipo) {
      resultados = resultados.filter((m) => m.tipo === tipo)
    }

    // Filtrar por turno
    if (turno) {
      resultados = resultados.filter((m) => m.turno === turno)
    }

    // Filtrar por concepto
    if (conceptoId) {
      resultados = resultados.filter((m) => m.conceptoId === Number.parseInt(conceptoId))
    }

    // Filtrar por usuario
    if (usuarioId) {
      resultados = resultados.filter((m) => m.realizadoPorId === Number.parseInt(usuarioId))
    }

    // Filtrar por fecha (en una implementación real, esto sería más robusto)
    if (fechaDesde) {
      // Convertir fechaDesde a formato comparable
      resultados = resultados.filter((m) => {
        const partesFecha = m.fecha.split("/")
        const fechaMovimiento = new Date(`${partesFecha[2]}-${partesFecha[1]}-${partesFecha[0]}`)
        return fechaMovimiento >= new Date(fechaDesde)
      })
    }

    if (fechaHasta) {
      // Convertir fechaHasta a formato comparable
      resultados = resultados.filter((m) => {
        const partesFecha = m.fecha.split("/")
        const fechaMovimiento = new Date(`${partesFecha[2]}-${partesFecha[1]}-${partesFecha[0]}`)
        return fechaMovimiento <= new Date(fechaHasta)
      })
    }

    setMovimientosFiltrados(resultados)
  }

  // Limpiar filtros
  const limpiarFiltros = () => {
    setFechaDesde("")
    setFechaHasta("")
    setUsuarioId("")
    setConceptoId("")
    setTurno("")
    setTipo("")
    setReferenceId("")
    setMovimientosFiltrados(movimientos)
  }

  // Exportar a CSV (simulado)
  const exportarCSV = () => {
    alert("Función de exportación a CSV (simulada)")
    // En una implementación real, esto generaría un archivo CSV
  }

  return (
    <div className="space-y-6">
      {/* Filtros */}
      <Card>
        <CardHeader>
          <CardTitle>Filtros de búsqueda</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label htmlFor="fechaDesde">Fecha desde</Label>
              <Input id="fechaDesde" type="date" value={fechaDesde} onChange={(e) => setFechaDesde(e.target.value)} />
            </div>

            <div className="space-y-2">
              <Label htmlFor="fechaHasta">Fecha hasta</Label>
              <Input id="fechaHasta" type="date" value={fechaHasta} onChange={(e) => setFechaHasta(e.target.value)} />
            </div>

            <div className="space-y-2">
              <Label htmlFor="usuario">Usuario</Label>
              <Select value={usuarioId} onValueChange={setUsuarioId}>
                <SelectTrigger>
                  <SelectValue placeholder="Todos los usuarios" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos los usuarios</SelectItem>
                  {usuarios.map((usuario) => (
                    <SelectItem key={usuario.id} value={usuario.id.toString()}>
                      {usuario.nombre}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="concepto">Concepto</Label>
              <Select value={conceptoId} onValueChange={setConceptoId}>
                <SelectTrigger>
                  <SelectValue placeholder="Todos los conceptos" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos los conceptos</SelectItem>
                  {conceptos.map((concepto) => (
                    <SelectItem key={concepto.id} value={concepto.id.toString()}>
                      {concepto.nombre}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="turno">Turno</Label>
              <Select value={turno} onValueChange={setTurno}>
                <SelectTrigger>
                  <SelectValue placeholder="Todos los turnos" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos los turnos</SelectItem>
                  <SelectItem value="M">Mañana (M)</SelectItem>
                  <SelectItem value="T">Tarde (T)</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="tipo">Tipo</Label>
              <Select value={tipo} onValueChange={setTipo}>
                <SelectTrigger>
                  <SelectValue placeholder="Todos los tipos" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos los tipos</SelectItem>
                  <SelectItem value="Ingreso">Ingreso</SelectItem>
                  <SelectItem value="Egreso">Egreso</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="referenceId">ID de referencia</Label>
              <Input
                id="referenceId"
                placeholder="Buscar por ID"
                value={referenceId}
                onChange={(e) => setReferenceId(e.target.value)}
              />
            </div>
          </div>

          <div className="flex justify-end gap-2 mt-6">
            <Button variant="outline" onClick={limpiarFiltros}>
              Limpiar filtros
            </Button>
            <Button onClick={aplicarFiltros}>
              <Search className="h-4 w-4 mr-2" />
              Buscar
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Resultados */}
      <Card>
        <CardHeader>
          <div className="flex justify-between items-center">
            <CardTitle>Resultados ({movimientosFiltrados.length})</CardTitle>
            <Button variant="outline" onClick={exportarCSV}>
              <FileDown className="h-4 w-4 mr-2" />
              Exportar CSV
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>ID</TableHead>
                  <TableHead>Tipo</TableHead>
                  <TableHead>Fecha</TableHead>
                  <TableHead>Turno</TableHead>
                  <TableHead>Concepto</TableHead>
                  <TableHead className="text-right">Monto</TableHead>
                  <TableHead>Realizado por</TableHead>
                  <TableHead>Detalle</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {movimientosFiltrados.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={8} className="text-center py-4">
                      No se encontraron resultados
                    </TableCell>
                  </TableRow>
                ) : (
                  movimientosFiltrados.map((movimiento) => (
                    <TableRow key={movimiento.id}>
                      <TableCell className="font-medium">{movimiento.id}</TableCell>
                      <TableCell>
                        <div className="flex items-center">
                          {movimiento.tipo === "Ingreso" ? (
                            <ArrowUpCircle className="h-4 w-4 text-green-500 mr-1" />
                          ) : (
                            <ArrowDownCircle className="h-4 w-4 text-red-500 mr-1" />
                          )}
                          {movimiento.tipo}
                        </div>
                      </TableCell>
                      <TableCell>{movimiento.fecha}</TableCell>
                      <TableCell>{movimiento.turno}</TableCell>
                      <TableCell>{movimiento.conceptoNombre}</TableCell>
                      <TableCell className="text-right">
                        <span className={movimiento.tipo === "Ingreso" ? "text-green-600" : "text-red-600"}>
                          ${movimiento.monto.toFixed(2)}
                        </span>
                      </TableCell>
                      <TableCell>{movimiento.realizadoPorNombre}</TableCell>
                      <TableCell className="max-w-[200px] truncate">{movimiento.detalle || "-"}</TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
