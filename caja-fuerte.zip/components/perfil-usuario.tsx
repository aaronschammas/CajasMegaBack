"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card"
import { useToast } from "@/hooks/use-toast"
import { User } from "lucide-react"

interface UsuarioData {
  id: number
  email: string
  fullName: string
  roleId: number
}

export default function PerfilUsuario() {
  const [usuario, setUsuario] = useState<UsuarioData | null>(null)
  const [nombreCompleto, setNombreCompleto] = useState("")
  const [email, setEmail] = useState("")
  const [contrasenaActual, setContrasenaActual] = useState("")
  const [nuevaContrasena, setNuevaContrasena] = useState("")
  const [confirmarContrasena, setConfirmarContrasena] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const { toast } = useToast()

  useEffect(() => {
    // Cargar datos del usuario desde localStorage
    const userStr = localStorage.getItem("user")
    if (userStr) {
      try {
        const userData = JSON.parse(userStr)
        setUsuario(userData)
        setNombreCompleto(userData.fullName || "")
        setEmail(userData.email || "")
      } catch (e) {
        console.error("Error al cargar datos del usuario", e)
      }
    }
  }, [])

  const handleUpdateProfile = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    try {
      // En una implementación real, esto sería una llamada a la API
      // const response = await fetch("/api/users/profile", {
      //   method: "PUT",
      //   headers: {
      //     "Content-Type": "application/json",
      //     "Authorization": `Bearer ${localStorage.getItem("token")}`
      //   },
      //   body: JSON.stringify({ fullName: nombreCompleto }),
      // });

      // if (!response.ok) {
      //   throw new Error("Error al actualizar el perfil");
      // }

      // Simulamos una respuesta exitosa
      // Actualizamos el localStorage
      if (usuario) {
        const updatedUser = {
          ...usuario,
          fullName: nombreCompleto,
        }
        localStorage.setItem("user", JSON.stringify(updatedUser))
        setUsuario(updatedUser)
      }

      toast({
        title: "Perfil actualizado",
        description: "Tu información de perfil ha sido actualizada correctamente",
      })
    } catch (error) {
      toast({
        title: "Error",
        description: "No se pudo actualizar el perfil",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault()

    // Validaciones básicas
    if (nuevaContrasena !== confirmarContrasena) {
      toast({
        title: "Error",
        description: "Las contraseñas no coinciden",
        variant: "destructive",
      })
      return
    }

    if (nuevaContrasena.length < 6) {
      toast({
        title: "Error",
        description: "La contraseña debe tener al menos 6 caracteres",
        variant: "destructive",
      })
      return
    }

    setIsLoading(true)

    try {
      // En una implementación real, esto sería una llamada a la API
      // const response = await fetch("/api/users/change-password", {
      //   method: "POST",
      //   headers: {
      //     "Content-Type": "application/json",
      //     "Authorization": `Bearer ${localStorage.getItem("token")}`
      //   },
      //   body: JSON.stringify({
      //     currentPassword: contrasenaActual,
      //     newPassword: nuevaContrasena
      //   }),
      // });

      // if (!response.ok) {
      //   throw new Error("Error al cambiar la contraseña");
      // }

      // Simulamos una respuesta exitosa
      toast({
        title: "Contraseña actualizada",
        description: "Tu contraseña ha sido actualizada correctamente",
      })

      // Limpiar campos
      setContrasenaActual("")
      setNuevaContrasena("")
      setConfirmarContrasena("")
    } catch (error) {
      toast({
        title: "Error",
        description: "No se pudo cambiar la contraseña",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  if (!usuario) {
    return <div>Cargando información del usuario...</div>
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
      {/* Información de perfil */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <User className="h-5 w-5" />
            Información de perfil
          </CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleUpdateProfile} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input id="email" type="email" value={email} disabled className="bg-gray-50" />
              <p className="text-xs text-gray-500">El email no se puede cambiar</p>
            </div>

            <div className="space-y-2">
              <Label htmlFor="nombreCompleto">Nombre completo</Label>
              <Input
                id="nombreCompleto"
                value={nombreCompleto}
                onChange={(e) => setNombreCompleto(e.target.value)}
                required
              />
            </div>

            <div className="space-y-2">
              <Label>Rol</Label>
              <Input
                value={usuario.roleId === 1 ? "Administrador General" : "Usuario Normal"}
                disabled
                className="bg-gray-50"
              />
            </div>
          </form>
        </CardContent>
        <CardFooter>
          <Button type="submit" onClick={handleUpdateProfile} disabled={isLoading} className="w-full">
            {isLoading ? "Actualizando..." : "Actualizar perfil"}
          </Button>
        </CardFooter>
      </Card>

      {/* Cambio de contraseña */}
      <Card>
        <CardHeader>
          <CardTitle>Cambiar contraseña</CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleChangePassword} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="contrasenaActual">Contraseña actual</Label>
              <Input
                id="contrasenaActual"
                type="password"
                value={contrasenaActual}
                onChange={(e) => setContrasenaActual(e.target.value)}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="nuevaContrasena">Nueva contraseña</Label>
              <Input
                id="nuevaContrasena"
                type="password"
                value={nuevaContrasena}
                onChange={(e) => setNuevaContrasena(e.target.value)}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="confirmarContrasena">Confirmar nueva contraseña</Label>
              <Input
                id="confirmarContrasena"
                type="password"
                value={confirmarContrasena}
                onChange={(e) => setConfirmarContrasena(e.target.value)}
                required
              />
            </div>
          </form>
        </CardContent>
        <CardFooter>
          <Button type="submit" onClick={handleChangePassword} disabled={isLoading} className="w-full">
            {isLoading ? "Cambiando contraseña..." : "Cambiar contraseña"}
          </Button>
        </CardFooter>
      </Card>
    </div>
  )
}
