import type { Metadata } from "next"
import Link from "next/link"
import { Card, CardContent } from "@/components/ui/card"
import { ArrowDownCircle, ArrowUpCircle } from "lucide-react"
import Header from "@/components/header"

export const metadata: Metadata = {
  title: "Selección de Movimiento | Sistema de Control de Caja",
}

export default function MovimientosPage() {
  return (
    <div className="min-h-screen bg-gray-100">
      <Header />
      <main className="container mx-auto p-4 pt-24">
        <h1 className="text-2xl font-bold mb-6 text-center">Selección de Movimiento</h1>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-4xl mx-auto">
          <Card className="hover:shadow-lg transition-shadow">
            <CardContent className="p-6">
              <Link href="/movimientos/ingresos">
                <div className="flex flex-col items-center justify-center space-y-4 h-48">
                  <ArrowUpCircle className="h-16 w-16 text-green-500" />
                  <h2 className="text-xl font-semibold">Ingresos</h2>
                  <p className="text-center text-gray-500">Registrar entradas de dinero a la caja</p>
                </div>
              </Link>
            </CardContent>
          </Card>

          <Card className="hover:shadow-lg transition-shadow">
            <CardContent className="p-6">
              <Link href="/movimientos/egresos">
                <div className="flex flex-col items-center justify-center space-y-4 h-48">
                  <ArrowDownCircle className="h-16 w-16 text-red-500" />
                  <h2 className="text-xl font-semibold">Egresos</h2>
                  <p className="text-center text-gray-500">Registrar salidas de dinero de la caja</p>
                </div>
              </Link>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  )
}
