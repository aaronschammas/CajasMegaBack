import type { Metadata } from "next"
import Header from "@/components/header"
import MovimientoForm from "@/components/movimiento-form"

export const metadata: Metadata = {
  title: "Gestión de Egresos | Sistema de Control de Caja",
}

export default function EgresosPage() {
  return (
    <div className="min-h-screen bg-gray-100">
      <Header />
      <main className="container mx-auto p-4 pt-24">
        <h1 className="text-2xl font-bold mb-6">Gestión de Egresos</h1>
        <MovimientoForm tipo="Egreso" />
      </main>
    </div>
  )
}
