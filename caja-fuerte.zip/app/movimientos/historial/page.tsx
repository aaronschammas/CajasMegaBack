import type { Metadata } from "next"
import Header from "@/components/header"
import HistorialMovimientos from "@/components/historial-movimientos"

export const metadata: Metadata = {
  title: "Historial de Movimientos | Sistema de Control de Caja",
}

export default function HistorialPage() {
  return (
    <div className="min-h-screen bg-gray-100">
      <Header />
      <main className="container mx-auto p-4 pt-24">
        <h1 className="text-2xl font-bold mb-6">Historial de Movimientos</h1>
        <HistorialMovimientos />
      </main>
    </div>
  )
}
