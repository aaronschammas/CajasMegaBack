import type { Metadata } from "next"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card"

export const metadata: Metadata = {
  title: "Recuperar Contraseña | Sistema de Control de Caja",
}

export default function ForgotPasswordPage() {
  return (
    <main className="flex min-h-screen flex-col items-center justify-center p-4 bg-gray-100">
      <Card className="w-full max-w-md">
        <CardHeader>
          <CardTitle className="text-center">Recuperar Contraseña</CardTitle>
        </CardHeader>
        <CardContent>
          <form className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input id="email" type="email" placeholder="usuario@ejemplo.com" required />
            </div>
            <Button type="submit" className="w-full">
              Solicitar recuperación
            </Button>
          </form>
          <div className="mt-4 text-center text-sm text-gray-500">
            <p>Se notificará al administrador del sistema para que restablezca tu contraseña.</p>
          </div>
        </CardContent>
        <CardFooter className="flex justify-center">
          <Link href="/">
            <Button variant="link">Volver al inicio de sesión</Button>
          </Link>
        </CardFooter>
      </Card>
    </main>
  )
}
