import type { Metadata } from "next"
import Header from "@/components/header"
import PerfilUsuario from "@/components/perfil-usuario"

export const metadata: Metadata = {
  title: "Perfil de Usuario | Sistema de Control de Caja",
}

export default function PerfilPage() {
  return (
    <div className="min-h-screen bg-gray-100">
      <Header />
      <main className="container mx-auto p-4 pt-24">
        <h1 className="text-2xl font-bold mb-6">Perfil de Usuario</h1>
        <PerfilUsuario />
      </main>
    </div>
  )
}
