import { NextResponse } from "next/server"

// Simulación de usuarios en la base de datos
const users = [
  {
    id: 1,
    email: "admin@ejemplo.com",
    password: "admin123", // En producción, esto sería un hash
    fullName: "Administrador",
    roleId: 1, // Administrador General
  },
  {
    id: 2,
    email: "usuario@ejemplo.com",
    password: "usuario123", // En producción, esto sería un hash
    fullName: "Usuario Normal",
    roleId: 2, // Usuario Normal
  },
]

export async function POST(request: Request) {
  try {
    const { email, password } = await request.json()

    // Buscar usuario por email
    const user = users.find((u) => u.email === email)

    // Verificar si el usuario existe y la contraseña es correcta
    if (!user || user.password !== password) {
      return NextResponse.json({ error: "Credenciales inválidas" }, { status: 401 })
    }

    // En producción, usaríamos una biblioteca como jsonwebtoken para generar un token JWT real
    const token = `simulated-jwt-token-${user.id}-${Date.now()}`

    // Devolver información del usuario (sin la contraseña) y el token
    return NextResponse.json({
      user: {
        id: user.id,
        email: user.email,
        fullName: user.fullName,
        roleId: user.roleId,
      },
      token,
    })
  } catch (error) {
    console.error("Error en login:", error)
    return NextResponse.json({ error: "Error interno del servidor" }, { status: 500 })
  }
}
